# www.google.com -> bit.ly/f8249f0ewf
# create a url shortener that takes a url and converts it into a url that starts with bit.ly/<random characters>
# create a function that takes the shortened url and returns its original url (bit.ly/f8249f0ewf -> www.google.com)

# note: use a tool that makes sure that the characters of the short url are unique
# hint: use hashlib