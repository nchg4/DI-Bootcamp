from math import sqrt  # math - good for basic mathematical operations
from datetime import datetime, date


res = sqrt(16)
print(res)


today_dt = datetime.now()

today_date = date.today()

print(today_dt)
print(today_date)
