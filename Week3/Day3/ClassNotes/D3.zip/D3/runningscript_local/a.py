def add_two(n1, n2):
    return n1 + n2


def main():
    x1 = 10
    x2 = 20
    result = add_two(x1, x2)

    print("FROM a.py: ", result)


if __name__ == "__main__":  # run this if you run file directly
    main()
