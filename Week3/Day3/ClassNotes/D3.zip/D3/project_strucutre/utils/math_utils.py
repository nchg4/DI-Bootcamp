def add_two(num1: int, num2: int) -> int:
    return num1 + num2
