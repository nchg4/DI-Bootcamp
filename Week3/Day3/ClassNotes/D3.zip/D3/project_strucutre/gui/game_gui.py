board = """
    []
    []
    []"""
    
def present_board():
    ...