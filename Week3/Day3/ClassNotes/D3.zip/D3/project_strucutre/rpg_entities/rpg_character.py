class RPGCharacter:
    ...
    
    
if __name__ == "__main__":
    a_character = RPGCharacter() # test locally in rpg_character.py