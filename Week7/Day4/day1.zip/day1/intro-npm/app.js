// const slugify = require('slugify')
import slugify from "slugify";

console.log(slugify('i love nodejs'));