const greet = (name) => {
  return "Hello," + name;
};

module.exports = {
    greet
}
