numbers = [4, 2, 6, 2, 1]

largest_number = max(numbers)

print(largest_number)


words = ["abvc", "asdasd", "asdasfads", "hgfdh rt", "dfvg"]

longest_word = max(words, key=len)


print(longest_word)
